import React, { useRef, useState, useEffect } from "react";
import { View, Text, Image, StyleSheet, FlatList, Dimensions } from "react-native";

const screenWidth = Dimensions.get("window").width;

const TestimonialScreen = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const testimonials = [
    {
      profileImage: require("./assets/Card.png"),
      clientName: "Andrea",
      clientLocation: "CHENNAI",
      clientFeedback: "Greenheap delivers outstanding craftsmanship with truly unique pieces. Their customer service was attentive and guided me through every step. The entire experience was smooth and enjoyable."
    },
    {
      profileImage: require("./assets/Card.png"),
      clientName: "John",
      clientLocation: "MUMBAI",
      clientFeedback: "I was amazed by the quality of the jewelry. The designs are exquisite, and the team was very helpful throughout the process."
    },
    {
      profileImage: require("./assets/Card.png"),
      clientName: "Emily",
      clientLocation: "BANGALORE",
      clientFeedback: "Absolutely love my new piece! The craftsmanship is top-notch, and I received it in a timely manner. Highly recommend!"
    },
    {
      profileImage: require("./assets/Card.png"),
      clientName: "Michael",
      clientLocation: "DELHI",
      clientFeedback: "The service was exceptional, and the jewelry is stunning. I will definitely be coming back for more!"
    }
  ];

  return (
    <View style={styles.container}>
      {/* Jewelry Images */}
      <View style={styles.imageContainer}>
        <Image source={require("./assets/client/client1.png")} style={styles.image} />
        <Image source={require("./assets/client/client2.png")} style={styles.image} />
        <Image source={require("./assets/client/client3.png")} style={styles.image} />
        <Image source={require("./assets/client/client4.png")} style={styles.image} />
      </View>

      {/* Client Testimonial */}
      <Text style={styles.heading}>CLIENT SAY’S..?</Text>

      {/* Horizontal Scrolling Testimonial Cards */}
      <FlatList
        data={testimonials}
        keyExtractor={(item, index) => index.toString()}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TestimonialCard {...item} />
        )}
      />

      {/* Pagination Dots */}
      <View style={styles.paginationContainer}>
        {testimonials.map((_, index) => (
          <View key={index} style={[styles.dot, currentIndex === index && styles.activeDot]} />
        ))}
      </View>
    </View>
  );
};

const TestimonialCard = ({ profileImage, clientName, clientLocation, clientFeedback }) => {
  return (
    <View style={styles.card}>
      <Image source={profileImage} style={styles.profileImage} />
      <Text style={styles.clientName}>{clientName}</Text>
      <Text style={styles.clientLocation}>{clientLocation}</Text>
      <Text style={styles.clientFeedback}>{clientFeedback}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    padding: 16,
    backgroundColor: "#fff",
  },
  imageContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 20,
  },
  image: {
    width: 148,
    height: 268,
    marginHorizontal: 0,
  },
  heading: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 16,
  },
  card: {
    width: screenWidth * 0.8,
    backgroundColor: "white",
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
    elevation: 4,
    borderWidth: 2,
    borderColor: "#ccc",
    marginRight: 16,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 10,
  },
  clientName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  clientLocation: {
    fontSize: 12,
    color: "gray",
    marginBottom: 10,
  },
  clientFeedback: {
    fontSize: 14,
    textAlign: "center",
    color: "#333",
  },
  paginationContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#ccc",
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: "#333",
  },
});

export default TestimonialScreen;
