import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Image, StyleSheet } from 'react-native';

const FAQ_DATA = [
  { id: '1', question: '1.What is Digital Gold by Digi?', answer: 'Digital Gold is a way to invest in gold online.' },
  { id: '2', question: '2.What is Digital Gold Locker Wallet?', answer: 'A secure wallet to store your digital gold.' },
  { id: '3', question: '3.What is Live Gold Price?', answer: 'Live gold price is the real-time price of gold in the market.' },
  { id: '4', question: '4.How Often Does the Live Price Range?', answer: 'Live price updates frequently based on market fluctuations.' },
  { id: '5', question: '5.How Long is the Live Price Valid for Completing a Transaction?', answer: 'The price is valid for a limited time before updating.' }
];

const App = () => {
  const [expanded, setExpanded] = useState(null);

  const toggleExpand = (id) => {
    setExpanded(expanded === id ? null : id);
  };

  const renderFAQItem = (item) => (
    <View key={item.id} style={styles.faqItem}>
      <TouchableOpacity onPress={() => toggleExpand(item.id)} style={styles.questionRow}>
        <Text style={styles.question}>{item.question}</Text>
        <Text style={styles.icon}>{expanded === item.id ? '▼' : '▶'}</Text>
      </TouchableOpacity>
      {expanded === item.id && <Text style={styles.answer}>{item.answer}</Text>}
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Frequently Asked Questions</Text>
      <ScrollView>
        {FAQ_DATA.map((item) => renderFAQItem(item))}
      </ScrollView>
      <TouchableOpacity style={styles.viewAllButton}>
        <Text style={styles.viewAllText}>View All</Text>
      </TouchableOpacity>
      
      <Text style={styles.digiGoldTitle}>Digi Gold</Text>
      <View style={styles.imageContainer}>
        <Image source={require('./assets/client/client1.png')} style={styles.image} />
        <Image source={require('./assets/client/client2.png')} style={styles.image} />
      </View>
      <TouchableOpacity style={styles.digiGoldButton}>
        <Text style={styles.digiGoldButtonText}>Digi Gold Online</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#732626' },
  faqItem: { borderBottomWidth: 1, borderBottomColor: '#ccc', paddingVertical: 10 },
  questionRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  question: { fontSize: 16, color: '#000' },
  icon: { fontSize: 16, color: '#732626' },
  answer: { marginTop: 5, fontSize: 14, color: '#555' },
  viewAllButton: { marginTop: 10, alignSelf: 'center', padding: 10, borderWidth: 1, borderRadius: 5 },
  viewAllText: { color: '#732626' },
  digiGoldTitle: { fontSize: 18, fontWeight: 'bold', textAlign: 'center', marginVertical: 15, color: '#732626' },
  imageContainer: { flexDirection: 'row', justifyContent: 'center', gap: 10 },
  image: { width: 100, height: 100, borderRadius: 50 },
  digiGoldButton: { marginTop: 15, backgroundColor: '#732626', padding: 10, borderRadius: 5, alignSelf: 'center' },
  digiGoldButtonText: { color: '#fff', fontSize: 16 }
});


export default App;
