import React, { useState } from "react";
import { View, Text, TouchableOpacity, Image, StyleSheet } from "react-native";

const HowItWorks = () => {
  const [selected, setSelected] = useState("Buy");

  const steps = [
    { id: 1, title: "Login", description: "Login or register with DigiGold and complete eKYC to set up your account." },
    { id: 2, title: "Enter Amount", description: "Enter your amount in rupees or gold in grams to buy." },
    { id: 3, title: "Payment", description: "Choose your payment method: account, card, or wallet." },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.header}>How it Works</Text>
      <Text style={styles.subHeader}>Bringing Convenience And Safety To Buy Gold Or Silver!</Text>
      
      <View style={styles.toggleContainer}>
        <TouchableOpacity
          style={[styles.toggleButton, selected === "Buy" && styles.selectedButton]}
          onPress={() => setSelected("Buy")}
        >
          <Text style={[styles.toggleText, selected === "Buy" && styles.selectedText]}>Buy</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.toggleButton, selected === "Sell" && styles.selectedButton]}
          onPress={() => setSelected("Sell")}
        >
          <Text style={[styles.toggleText, selected === "Sell" && styles.selectedText]}>Sell</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.stepContainer}>
        {steps.map((step) => (
          <View key={step.id} style={styles.stepBox}>
            <View style={styles.stepCircle}>
              <Text style={styles.stepLabel}>STEP</Text>
              <Text style={styles.stepNumber}>{step.id.toString().padStart(2, '0')}</Text>
            </View>
            <Text style={styles.stepTitle}>{step.title}</Text>
            <Text style={styles.stepDescription}>{step.description}</Text>
            <Image source={require("./assets/butterfly.png")} style={styles.icon} />
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: "center", backgroundColor: "white", flex: 1 },
  header: { fontSize: 22, fontWeight: "bold", color: "#5E051D", marginBottom: 5 },
  subHeader: { fontSize: 14, color: "#666", textAlign: "center", marginBottom: 20 },
  toggleContainer: { flexDirection: "row", borderWidth: 1, borderRadius: 6, overflow: "hidden", borderColor: "#000", width: 218, height: 51, justifyContent: "space-around", alignItems: "center" },
  toggleButton: { width: 86, height: 40, justifyContent: "center", alignItems: "center",borderRadius: 6, backgroundColor: "white" },
  selectedButton: { backgroundColor: "#5E051D" },
  toggleText: { fontSize: 16, color: "black" },
  selectedText: { color: "white" },
  stepContainer: { marginTop: 20, width: "100%", alignItems: "center", backgroundColor: "#FFF", padding: 15, borderRadius: 10, elevation: 3 },
  stepBox: { alignItems: "center", marginBottom: 20 },
  stepCircle: { width: 76, height: 76, borderRadius: 38, backgroundColor: "white", justifyContent: "center", alignItems: "center", shadowColor: "#000", shadowOpacity: 0.1, shadowRadius: 5, elevation: 3 },
  stepLabel: { fontSize: 12, color: "gray", fontWeight: "bold" },
  stepNumber: { fontSize: 24, fontWeight: "bold", color: "#5E051D" },
  stepTitle: { fontSize: 18, fontWeight: "light", color: "#5E051D", marginTop: 5 },
  stepDescription: { fontSize: 14, textAlign: "center", color: "#444", marginTop: 5 },
  icon: { width: 73, height: 73, marginTop: 10 },
});

export default HowItWorks;