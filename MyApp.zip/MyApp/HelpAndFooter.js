import React from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  Linking,
  ScrollView,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const HelpScreen = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image source={require('./assets/moneybag.png')} style={styles.image} />

      <Text style={styles.title}>Need Help</Text>
      <Text style={styles.subtitle}>
        Drop your number and we'll contact you shortly. Or raise a ticket to get in touch with our DigiGold support team.
      </Text>

      <View style={styles.form}>
        <TextInput
          style={styles.input}
          placeholder="Full Name*"
          placeholderTextColor="#777"
        />
        <TextInput
          style={styles.input}
          placeholder="Mobile *"
          placeholderTextColor="#777"
          keyboardType="phone-pad"
        />
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Request Callback</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.partnerHeading}>Our Trusted Partners</Text>
      <View style={styles.partnerLogos}>
        <Text style={styles.partnerText}>
          Amazon Pay | Axis Bank | CaratLane | Tanishq | PhonePe
        </Text>
      </View>

      <View style={styles.footer}>
        <View style={styles.footerColumns}>
          <View style={styles.footerSection}>
            <Text style={styles.footerHeading}>Useful</Text>
            {['About Us', 'Terms and Conditions', 'Privacy Policy', 'Refund & Cancellation Policy', 'Contact Us'].map((item, index) => (
              <Text key={index} style={styles.footerItem}>• {item}</Text>
            ))}
          </View>

          <View style={styles.footerSection}>
            <Text style={styles.footerHeading}>Contact Us</Text>
            <Text style={styles.footerItem}>
              <Entypo name="location-pin" size={16} /> No. 1/PL922, 66th St, 11th Sector, Kalaignar Karunanidhi Nagar, Chennai, India
            </Text>
            <Text style={styles.footerItem}>
              <MaterialIcons name="email" size={16} /> spprtgreenheapdigigold@gmail.com
            </Text>
            <Text style={styles.footerItem}>
              <Icon name="phone" size={16} /> +91 81900 59995
            </Text>
          </View>
        </View>

        <View style={styles.socialIcons}>
          <TouchableOpacity onPress={() => Linking.openURL('https://www.linkedin.com')}>
            <Icon name="linkedin-square" size={26} color="#0e76a8" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Linking.openURL('https://www.instagram.com')}>
            <Icon name="instagram" size={26} color="#C13584" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Linking.openURL('https://www.facebook.com')}>
            <Icon name="facebook-square" size={26} color="#4267B2" />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Linking.openURL('https://wa.me')}>
            <Icon name="whatsapp" size={26} color="#25D366" />
          </TouchableOpacity>
        </View>

        <Text style={styles.disclaimer}>
          Our organization ensures a seamless and transparent way to purchase and accumulate 24K gold digitally, converting to physical gold with full legal compliance.
        </Text>

        <Text style={styles.copy}>
          © 2025 Greenheap Gold And Silver Jewellery Private Limited.
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    padding: 20,
    paddingBottom: 40,
  },
  image: {
    width: 120,
    height: 120,
    alignSelf: 'center',
    marginBottom: 10,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 6,
    color: '#222',
  },
  subtitle: {
    fontSize: 14,
    textAlign: 'center',
    color: '#555',
    marginBottom: 20,
    lineHeight: 20,
  },
  form: {
    marginBottom: 25,
  },
  input: {
    borderWidth: 1,
    borderColor: '#bbb',
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 16,
    marginBottom: 12,
    backgroundColor: '#f9f9f9',
  },
  button: {
    backgroundColor: '#660000',
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  partnerHeading: {
    textAlign: 'center',
    fontWeight: '700',
    fontSize: 16,
    color: '#222',
    marginBottom: 5,
  },
  partnerLogos: {
    alignItems: 'center',
    marginBottom: 25,
  },
  partnerText: {
    color: '#444',
    fontSize: 14,
  },
  footer: {
    backgroundColor: '#3c0000',
    borderRadius: 10,
    padding: 20,
    marginTop: 10,
  },
  footerColumns: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 20,
  },
  footerSection: {
    flex: 1,
  },
  footerHeading: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 8,
  },
  footerItem: {
    color: '#ccc',
    fontSize: 14,
    marginBottom: 4,
    lineHeight: 20,
  },
  socialIcons: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    gap: 15,
    marginTop: 15,
    marginBottom: 10,
  },
  disclaimer: {
    fontSize: 12,
    color: '#ddd',
    marginTop: 10,
    lineHeight: 18,
  },
  copy: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 12,
    marginTop: 12,
  },
});

export default HelpScreen;


