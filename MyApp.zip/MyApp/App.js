import React from 'react';
import { ScrollView} from 'react-native';
import BuyDigitalGold from './BuyDigitalGold';
import HowItWorks from "./HowItWorks";
import Scheme from "./Scheme";
import ClientPage from "./ClientPage";
import WhyDigiGold from "./WhyDigiGold";
import RefundPolicy from "./Refund Policy";
import FAQ from "./FreqQnpage";
import AboutUs from'./AboutUs';
import Help from './HelpAndFooter';
export default function App() {
  return (
    <ScrollView>
      <BuyDigitalGold />
      <HowItWorks />
      <Scheme />
      <ClientPage />
      <WhyDigiGold />
      <FAQ />
      <RefundPolicy />
      <AboutUs />   
      <Help />
    </ScrollView>
  );
}

