import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

const LivePriceCard = () => {
  const prices = [
    { metal: 'Gold', purity: '22k', price: '7980', color: '#FFD700' },
    { metal: 'Gold', purity: '24k', price: '8980', color: '#FFD700' },
    { metal: 'Silver', purity: '99.9%', price: '107', color: '#C0C0C0' },
  ];

  const titleOpacity = useRef(new Animated.Value(1)).current;
  const radioButtonOpacity = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const blink = () => {
      Animated.sequence([
        Animated.parallel([
          Animated.timing(titleOpacity, {
            toValue: 0,
            duration: 500,
            useNativeDriver: true,
          }),
          Animated.timing(radioButtonOpacity, {
            toValue: 0,
            duration: 500,
            useNativeDriver: true,
          }),
        ]),
        Animated.parallel([
          Animated.timing(titleOpacity, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          }),
          Animated.timing(radioButtonOpacity, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          }),
        ]),
      ]).start(() => blink());
    };

    blink();
  }, [titleOpacity, radioButtonOpacity]);

  return (
    <View style={styles.container}>
      <View style={styles.titleContainer}>
        <Animated.View style={[styles.radioButton, { opacity: radioButtonOpacity }]}>
          <Svg height="20" width="20">
            <Circle cx="10" cy="10" r="8" stroke="red" strokeWidth="1" fill="#FFFFFF" />
            <Circle cx="10" cy="10" r="4" fill="#FF7F7F" />
          </Svg>
        </Animated.View>
        <Animated.Text style={[styles.title, { opacity: titleOpacity }]}>Live Price</Animated.Text>
      </View>
      <View style={styles.underline} />
      {prices.map((item, index) => (
        <View key={index} style={styles.item}>
          <Svg height="20" width="20" style={styles.radioButton}>
            <Circle cx="10" cy="10" r="0" stroke="black" strokeWidth="1" fill="lightgray" />
            <Circle cx="10" cy="10" r="4" fill="red" />
          </Svg>
          <Text style={styles.metal}>
            {item.metal} <Text style={[styles.purity, { color: item.color }]}>{item.purity}</Text>
          </Text>
          <Text>
            <Text style={styles.price}>{item.price}/gm</Text>
            <Text style={styles.tax}> +3% GST applicable</Text>
          </Text>
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#FFD700',
    width: 300,
    marginLeft: 0,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 17,
    fontWeight: 'bold',
    color: 'black',
    marginLeft: 25,
  },
  underline: {
    height: 2,
    backgroundColor: '#FFD700',
    marginBottom: 10,
  },
  item: {
    marginBottom: 10,
  },
  radioButton: {
    position: 'absolute',
    left: 0,
    top: 2,
  },
  metal: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'gray',
    marginLeft: 20,
  },
  purity: {
    fontWeight: 'bold',
  },
  price: {  
    fontSize: 13,
    fontWeight: 'bold',
    marginLeft: 35,
    color: 'black',
    textAlign: 'center',
  },
  tax: {
    fontSize: 8,
    color: 'gray',
    marginLeft: 30,
  },
});

export default LivePriceCard;
