import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';
import { Card } from 'react-native-paper';

const DigiGoldInfo = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Why Choose Digi Gold over Physical Gold</Text>

      {/* Affordability Section */}
      <Card style={styles.card}>
        <View style={styles.cardContent}>
          <Image source={require('./assets/moneybag.png')} style={styles.icon} />
          <View style={styles.textContainer}>
            <Text style={styles.title}>Affordability</Text>
            <Text style={styles.description}>• At DIGIGOLD, we offer the most competitive prices.</Text>
            <Text style={styles.description}>• Ensuring unmatched value on all our products.</Text>
            <Text style={styles.description}>• Our rates are consistently aligned with live market trends.</Text>
          </View>
        </View>
      </Card>

      {/* Butterfly */}
      <Image source={require('./assets/butterfly2.png')} style={styles.butterfly} />

      {/* Systematic Growth Section */}
      <Card style={styles.card}>
        <View style={styles.cardContent}>
          <Image source={require('./assets/growth.png')} style={styles.icon} />
          <View style={styles.textContainer}>
            <Text style={styles.title}>Systematic Growth</Text>
            <Text style={styles.description}>• Achieve steady and systematic growth with DIGIGOLD.</Text>
            <Text style={styles.description}>• No lock-in period SIP in Gold offers flexibility.</Text>
            <Text style={styles.description}>• Invest at your pace and maximize returns.</Text>
            <Text style={styles.description}>• Secure your future with the power of smart investments.</Text>
          </View>
        </View>
      </Card>

      {/* Butterfly */}
      <Image source={require('./assets/butterfly2.png')} style={styles.butterfly} />

      {/* Guaranteed Purity Section */}
      <Card style={styles.card}>
        <View style={styles.cardContent}>
          <Image source={require('./assets/badge.png')} style={styles.icon} />
          <View style={styles.textContainer}>
            <Text style={styles.title}>Guaranteed Purity</Text>
            <Text style={styles.description}>• We guarantee the purest 24-karat gold, crafted with 99.9% purity.</Text>
            <Text style={styles.description}>• Every product is BIS Hallmarked, ensuring authenticity.</Text>
            <Text style={styles.description}>• Invest with confidence and complete trust.</Text>
          </View>
        </View>
      </Card>

      {/* Butterfly */}
      <Image source={require('./assets/butterfly2.png')} style={styles.butterfly} />

      {/* Security Section */}
      <Card style={styles.card}>
        <View style={styles.cardContent}>
          <Image source={require('./assets/security.png')} style={styles.icon} />
          <View style={styles.textContainer}>
            <Text style={styles.title}>Security</Text>
            <Text style={styles.description}>• Your investments deserve the highest level of security.</Text>
            <Text style={styles.description}>• With DIGIGOLD, every transaction is safeguarded with advanced encryption.</Text>
            <Text style={styles.description}>• We ensure complete transparency and trust.</Text>
          </View>
        </View>
      </Card>

      {/* FAQ Section */}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
  },
  header: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#5E051D',
    marginBottom: 20,
  },
  card: {
    width: '100%',
    padding: 15,
    marginBottom: 20,
    borderRadius: 10,
    backgroundColor: '#fff',
    elevation: 3, // Adds a shadow for better UI
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    width: 60,
    height: 60,
    marginRight: 15,
  },
  textContainer: {
    flex: 1,
    
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  description: {
    fontSize: 14,
    color: '#333',
  },
  butterfly: {
    width: 80,
    height: 60,
    marginBottom: 10,
  },
});

export default DigiGoldInfo;
