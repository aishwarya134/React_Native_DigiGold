import React, { useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, TouchableWithoutFeedback, Animated, StyleSheet, Easing } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const MenuDrawer = ({ isVisible, onClose }) => {
  const slideAnim = useRef(new Animated.Value(-100)).current; // Start off-screen

  useEffect(() => {
    Animated.timing(slideAnim, {
      toValue: isVisible ? 0 : -250,
      duration: 300,
      easing: Easing.out(Easing.ease),
      useNativeDriver: false, // Important for layout animations
    }).start();
  }, [isVisible]);

  
  if (!isVisible) return null; // Prevent unnecessary renders

  return (
    <View style={styles.fullscreenContainer}>
      {/* Background Overlay */}
      <TouchableWithoutFeedback onPress={onClose}>
        <View style={styles.overlay} />
      </TouchableWithoutFeedback>

      {/* Drawer Menu */}
      <Animated.View style={[styles.menuContainer, { transform: [{ translateX: slideAnim }] }]}>
        {/* Close Button */}
        <TouchableOpacity style={styles.closeButton} onPress={onClose}>
          <Icon name="close" size={24} color="white" />
        </TouchableOpacity>

        {/* Profile Section */}
        <View style={styles.profileSection}>
          <Icon name="account-circle" size={60} color="white" />
          <Text style={styles.username}>Adhi</Text>
          <Text style={styles.userPhone}>99XXXXXX04</Text>
        </View>

        {/* Menu Items */}
        <View style={styles.menuItems}>
          {['Buy', 'Sell', 'Transaction', 'Terms and Condition'].map((item, index) => (
            <TouchableOpacity key={index} activeOpacity={0.7}>
              <Text style={styles.menuItem}>{item}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Logout */}
        <TouchableOpacity activeOpacity={0.7}>
          <Text style={styles.logout}>Log Out</Text>
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  fullscreenContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 9999, // Highest priority
    elevation: 10, // Ensures it's above everything on Android
  },

  overlay: { 
    position: 'absolute', 
    top: 0, left: 0, right: 0, bottom: 0, 
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },

  menuContainer: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: 250,
    height: '100%',
    backgroundColor: '#500020',
    paddingTop: 50,
    paddingHorizontal: 20,
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
    zIndex: 10000, // Ensures it appears on top
    elevation: 20, // Important for Android
  },

  closeButton: {
    position: 'absolute',
    top: 15,
    right: 15,
    padding: 10,
  },

  profileSection: { alignItems: 'center', marginBottom: 20 },
  username: { fontSize: 18, color: 'white', fontWeight: 'bold' },
  userPhone: { fontSize: 14, color: '#ccc' },

  menuItems: { borderTopWidth: 1, borderColor: '#ffcc00', marginTop: 10, paddingTop: 10 },
  menuItem: { fontSize: 16, color: 'white', paddingVertical: 10, borderBottomWidth: 1, borderColor: '#ffcc00' },

  logout: { marginTop: 20, fontSize: 16, color: 'white', textAlign: 'center' }
});

export default MenuDrawer;
