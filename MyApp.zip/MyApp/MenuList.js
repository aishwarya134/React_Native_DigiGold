import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

const MenuList = ({ onPressBuy, onPressSell, onPressTransaction, onPressAboutUs, onClose }) => {
  return (
    <View style={styles.menuList}>
      <TouchableOpacity style={styles.menuItem} onPress={() => { onPressBuy(); onClose(); }}>
        <Icon name="shopping-bag" size={20} color="black" />
        <Text style={styles.menuText}>BUY</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => { onPressSell(); onClose(); }}>
        <Icon name="upload" size={20} color="black" />
        <Text style={styles.menuText}>SELL</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => { onPressTransaction(); onClose(); }}>
        <Icon name="list" size={20} color="black" />
        <Text style={styles.menuText}>TRANSACTION</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => { onPressAboutUs(); onClose(); }}>
        <Icon name="info" size={20} color="black" />
        <Text style={styles.menuText}>ABOUT US</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  menuList: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    elevation: 3,
    paddingVertical: 6,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
  },
  menuText: {
    color: '#5E051D',
    fontSize: 13,
    marginLeft: 5,
  },
});

export default MenuList;
