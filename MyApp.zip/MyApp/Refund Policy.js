import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image } from 'react-native';

const RefundPolicy = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.imageContainer}>
        <Image source={require('./assets/client/client1.png')} style={styles.image} />
        <Image source={require('./assets/client/client2.png')} style={styles.image} />
        <Image source={require('./assets/client/client3.png')} style={styles.image} />
      </View>
      <Text style={styles.title}>Refund & Cancellation Policy</Text>
      <Text style={styles.bullet}>• Users can choose a monthly investment amount between ₹100 and ₹15,00,000.</Text>
      <Text style={styles.bullet}>• Investments in this scheme start from ₹100.</Text>
      <Text style={styles.bullet}>• The plan will activate once the user's cumulative investment reaches an amount equivalent to 1 gram of gold.</Text>
      <Text style={styles.bullet}>• Users will earn a return in Greenheap Gold based on their investment tenure. For example, at 3 months, a return of ₹7.50 is given, calculated at 0.25% per month on an investment of ₹1000.</Text>
      <Text style={styles.bullet}>• An additional bonus in the form of Silver is provided for each period. For example, after 3 months, the bonus is ₹24, calculated at 0.8% per month for an investment of ₹1000.</Text>
      <Text style={styles.bullet}>• If the user cancels the plan after making 5 payments out of a 6-month plan, the plan will be adjusted to reflect a 3-month duration. The user will receive the corresponding returns for the 3-month period, minus a 6% service charge.</Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  imageContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  image: {
    width: '32%',
    height: 100,
    resizeMode: 'cover',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8B0000',
    marginBottom: 10,
  },
  bullet: {
    fontSize: 14,
    marginBottom: 8,
    color: '#333',
  },
});

export default RefundPolicy;
