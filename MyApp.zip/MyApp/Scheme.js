import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

const PlanCard = ({ image, name, details }) => {
  return (
    <View style={styles.planCard}>
      <Image source={image} style={styles.planImage} />
      <Text style={styles.planName}>{name}</Text>
      <View style={styles.detailsContainer}>
        {details.map((detail, index) => (
          <Text key={index} style={styles.planDetail}>• {detail}</Text>
        ))}
      </View>
      <TouchableOpacity style={styles.buyNowButton}>
        <Text style={styles.buyNowText}>BUY NOW</Text>
        <Image source={require('./assets/buttons/arrow.png')} style={styles.arrowIcon} />
      </TouchableOpacity>
    </View>
  );
};

const SchemeScreen = () => {
  const plans = [
    {
      image: require('./assets/plan.png'),
      name: 'CHIT JEWEL SAVING PLAN',
      details: [
        "No Making Charges",
        "Get Cash back On Your Gold Purchase",
        "100% Returns",
        "Join Today Get 5 Gram Silver Free"
      ],
    },
    {
      image: require('./assets/plan2.png'),
      name: 'DIGI GOLD SIP PLAN',
      details: [
        "Just Start With 100",
        "Get Cash back On Your Gold Purchase",
        "100% Returns",
        "Join Today Get 2 Gram Silver Free"
      ],
    },
    {
      image: require('./assets/plan3.png'),
      name: 'GOLD FLEXI PLAN',
      details: [
        "Flexible Monthly Deposits",
        "Earn Bonus Gold",
        "100% Guaranteed Returns",
        "Join Today Get 3 Gram Silver Free"
      ],
    },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Choose Your Plan</Text>
      <Text style={styles.subtitle}>Quick Overview of Schemes</Text>
      
      {plans.map((plan, index) => (
        <PlanCard key={index} image={plan.image} name={plan.name} details={plan.details} />
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#5E051D',
    textAlign: 'center',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#555',
    textAlign: 'center',
    marginBottom: 20,
  },
  planCard: {
    width: width * 0.9,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4,
    marginBottom: 30,
    position: 'relative',
    paddingBottom: 30, // Extra space for button
  },
  planImage: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
    marginBottom: 10,
  },
  planName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#5E051D',
    textAlign: 'center',
  },
  detailsContainer: {
    alignSelf: 'stretch',
    alignItems: 'center',
    marginVertical: 10,
  },
  planDetail: {
    fontSize: 14,
    color: '#555',
    textAlign: 'left',
    width: '80%',
  },
  buyNowButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#5E051D',
    width: 73, // Fixed width
    height: 18.22, // Fixed height
    borderRadius: 10,
    justifyContent: 'center',
    position: 'absolute',
    bottom: 10, // Inside container
    right: 10,  // Bottom-right corner
  },
  buyNowText: {
    color: '#fff',
    fontSize: 10, // Adjusted for small button
    fontWeight: 'bold',
    marginRight: 5,
  },
  arrowIcon: {
    width: 8,
    height: 8,
    resizeMode: 'contain',
  },
});

export default SchemeScreen;
