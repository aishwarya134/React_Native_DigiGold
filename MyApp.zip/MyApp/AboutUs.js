import React from 'react';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';

const AboutUs = () => {
  return (
    <ScrollView style={styles.container}>
      
      {/* Top Jewelry Images */}
      <View style={styles.imageRow}>
        <Image source={require('./assets/A1.png')} style={styles.topImage} />
        <Image source={require('./assets/A2.png')} style={styles.topImage} />
        <Image source={require('./assets/A3.png')} style={styles.topImage} />
      </View>

      {/* About Us Section */}
      <View style={styles.aboutContainer}>
        <Text style={styles.heading}>ABOUT US</Text>
        <Text style={styles.subText}>
          Get access to the safest way of procuring... 24K Gold / Silver
        </Text>
        <Text style={styles.listItem}>
          • We at Digital Gold want to make your gold journey simple, transparent and trustworthy so that you can get the optimum output of your savings.
        </Text>
      </View>

      {/* Icons Section */}
      <View style={styles.iconRow}>
        <FeatureCard icon={require('./assets/delivery.png')} title="DELIVERY" />
        <FeatureCard icon={require('./assets/sip.png')} title="SIP PLAN" />
        <FeatureCard icon={require('./assets/gift.png')} title="GIFT" />
      </View>

      {/* Bottom Golden Cart */}
      <View style={styles.cartContainer}>
        <Image source={require('./assets/cart.png')} style={styles.cartImage} />
      </View>
    </ScrollView>
  );
};

const FeatureCard = ({ icon, title }) => (
  <TouchableOpacity style={styles.card}>
    <Image source={icon} style={styles.icon} />
    <Text style={styles.cardText}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    paddingVertical: 20,
  },
  imageRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginHorizontal: 10,
  },
  topImage: {
    width: 100,
    height: 140,
    borderRadius: 10,
  },
  aboutContainer: {
    padding: 20,
  },
  heading: {
    color: '#8B0000',
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 5,
  },
  subText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 10,
  },
  listItem: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
  },
  iconRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 20,
  },
  card: {
    alignItems: 'center',
    padding: 10,
    borderWidth: 1,
    borderColor: '#8B0000',
    borderRadius: 10,
    width: 90,
  },
  icon: {
    width: 30,
    height: 30,
    marginBottom: 8,
  },
  cardText: {
    fontSize: 12,
    textAlign: 'center',
    color: '#000',
  },
  cartContainer: {
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 50,
  },
  cartImage: {
    width: 120,
    height: 120,
    resizeMode: 'contain',
  },
});

export default AboutUs;
