import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  useWindowDimensions,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
} from 'react-native';
import Icon from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MenuList from './MenuList';
import LivePriceCard from './LivePriceCard';
import MenuDrawer from './MenuDrawer';
const images = [
  require('./assets/h1.png'),
  require('./assets/h2.png'),
  require('./assets/h3.png'),
  require('./assets/h4.png'),
  
];

const BuyDigitalGold = () => {
  const { width, height } = useWindowDimensions();
  const headerHeight = height * 0.12;
  const moveDown = height * 0.025;
  const [buyType, setBuyType] = useState('rupee');
  const [metal, setMetal] = useState('gold');
  const [carat, setCarat] = useState(24);
  const [amount, setAmount] = useState(0);
  const scrollRef = useRef(null);
  const [goldPrice, setGoldPrice] = useState(6000); // Sample price per gram
  const [silverPrice, setSilverPrice] = useState(75); // Sample price per gram
  const tax = useMemo(() => (metal === 'gold' ? amount * 0.09 : amount * 0.03), [metal, amount]);
  const totalAmount = useMemo(() => amount + tax, [amount, tax]);
  const [livePriceEnabled, setLivePriceEnabled] = useState(true);
  const [timer, setTimer] = useState(30); // Initial countdown in seconds
  const [menuVisible, setMenuVisible] = useState(false);

  useEffect(() => {
    if (livePriceEnabled) {
      const interval = setInterval(() => {
        setTimer((prev) => (prev > 0 ? prev - 1 : 30)); // Reset timer at 0
      }, 1000);
  
      return () => clearInterval(interval);
    }
  }, [livePriceEnabled]);
  
  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTo({
          x: currentIndex * width,
          animated: true,
        });
        currentIndex = (currentIndex + 1) % images.length;
      }
    }, 3000); // Auto-scroll every 3 seconds

    return () => clearInterval(interval);
  }, [width]);

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header */}
      <View style={[styles.header, { height: headerHeight, paddingTop: moveDown }]}>
        <View style={styles.leftSection}>
        <TouchableOpacity style={styles.menuButton} onPress={() => setMenuVisible(true)}>
        <Icon name="menu" size={28} color="white" />
          </TouchableOpacity>
          <Text style={styles.title}>DIGI GOLD</Text>
        </View>
        <MenuDrawer isVisible={menuVisible} onClose={() => setMenuVisible(false)}  />

      </View>

      {/* Menu Drawer */}
      <MenuDrawer isVisible={menuVisible} onClose={() => setMenuVisible(false)}  />
      {/* Main Content */}
      <ScrollView 
        style={styles.mainContent} 
        contentContainerStyle={styles.contentContainer} 
        scrollEventThrottle={16} 
        showsVerticalScrollIndicator={false}
      >
        {/* Image Carousel */}
        <View style={styles.imageWrapper}>
          <ScrollView
            ref={scrollRef}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            style={styles.imageContainer}
          >
            {images.map((img, index) => (
              <Image key={index} source={img} style={[styles.image, { width }]} resizeMode="cover" />
            ))}
          </ScrollView>
        </View>
        <View style={styles.livePriceContainer}>
          <LivePriceCard />
        </View>


        {/* Overlay Text Box */}
        <View style={styles.overlayTextContainer}>

          {/* Buy Digital Gold Section */}
          <Text style={styles.subtitle}>Invest Now</Text>

          {/* Buy Type Selection */}
          <View style={styles.row}>
            <TouchableOpacity onPress={() => setBuyType('rupee')} style={styles.radioButtonContainer}>
              <View style={[styles.radioCircle, buyType === 'rupee' && styles.selectedRadio]} />
              <Text style={styles.radioText}>Buy in Rupees</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => {
              setBuyType('gram');
              setAmount(0); // Reset amount when switching to grams
            }} style={styles.radioButtonContainer}>
              <View style={[styles.radioCircle, buyType === 'gram' && styles.selectedRadio]} />
              <Text style={styles.radioText}>Buy in Grams</Text>
            </TouchableOpacity>
          </View>

          {/* Metal Selection */}
          <View style={styles.row}>
            <TouchableOpacity
              style={[styles.metalButton, metal === 'gold' && styles.selectedMetal]}
              onPress={() => {
                setMetal('gold');
                setCarat(24); // Reset carat when switching to gold
              }}
            >
              <Text style={styles.buttonText}>Buy Gold</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.metalButton, metal === 'silver' && styles.selectedMetal]}
              onPress={() => {
                setMetal('silver');
                setCarat(null); // Reset carat when switching to silver
              }}
            >
              <Text style={styles.buttonText}>Buy Silver</Text>
            </TouchableOpacity>
          </View>

          {/* Carat Selection */}
          {metal === 'gold' && (
            <View style={styles.row}>
              <TouchableOpacity onPress={() => setCarat(22)} style={styles.radioButtonContainer}>
                <View style={[styles.radioCircle, carat === 22 && styles.selectedRadio]} />
                <Text style={styles.radioText}>22 K</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setCarat(24)} style={styles.radioButtonContainer}>
                <View style={[styles.radioCircle, carat === 24 && styles.selectedRadio]} />
                <Text style={styles.radioText}>24 K</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Amount Input */}
          <View style={styles.inputContainer}>
            <FontAwesome name="rupee" size={16} color="#5E051D" />
            <TextInput
              style={styles.input}
              keyboardType="numeric"
              placeholder="Enter Amount"
              value={amount.toString()}
              onChangeText={(text) => setAmount(Number(text) || 0)}
            />
            <Text>= 0 gm</Text>
          </View>

          {/* Quick Amount Buttons */}
          <View style={styles.amountRow}>
            {buyType === 'gram' ? [1, 2, 5, 10, 15].map((value) => (
              <TouchableOpacity key={value} style={styles.amountButton} onPress={() => setAmount((value / goldPrice).toFixed(2))}>
                <Text style={styles.amountText}>{value} gm</Text>
              </TouchableOpacity>
            )) : [100, 500, 1000, 10000, 100000].map((value) => (
              <TouchableOpacity key={value} style={styles.amountButton} onPress={() => setAmount(value)}>
                <Text style={styles.amountText}>₹{value}</Text>
              </TouchableOpacity>
            ))} 
          </View>

          {/* Summary Section */}
          <View style={styles.summaryContainer}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryText}>Amount :</Text>
              <Text style={styles.summaryText}>{amount}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryText}>Tax :</Text>
              <Text style={styles.summaryText}>{tax.toFixed(2)}</Text>
            </View>
            <View style={styles.separator} />
            <View style={styles.summaryRow}>
              <Text style={styles.totalText}>Total Amount :</Text>
              <Text style={styles.totalText}>{totalAmount.toFixed(2)}</Text>
            </View>
          </View>

          {/* Buy Now Button */}
          <TouchableOpacity style={styles.buyNowButton} onPress={() => console.log("Buy Now Pressed")}>
            <Text style={styles.buyNowText}>Buy Now</Text>
          </TouchableOpacity>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#fff' },
  header: { backgroundColor: '#5E051D', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20 },
  leftSection: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  menuButton: { paddingRight: 15 },
  title: { color: 'white', fontSize: 22, fontWeight: 'bold' },
  mainContent: { flex: 1 },
  contentContainer: { flexGrow: 1, paddingBottom: 50 },
  imageWrapper: { position: 'relative', height: 250, width: '100%' },
  livePriceContainer: {
    position: 'absolute',
    top: 180,
    left: 0,
    right: 0,
    zIndex: 1,
    alignItems: 'center',
  },

  imageContainer: { height: 200, marginBottom: 10 },
  image: { height: '100%', width: '100%' },
  overlayTextContainer: {
    marginTop: 130, // Adjust this value to position the overlay correctly
    width: '90%',
    alignSelf: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 15,
    borderRadius: 7,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
  },
  titleContainer: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 5,
  },
  overlayTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'gold',
    textAlign: 'center',
  },
  overlaySilverTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'silver',
    textAlign: 'left', 
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  priceText: {
    fontSize: 9,
    fontWeight: 'bold',
    color: '#5E051D',
  },
  subtitle: { marginTop:20, textAlign: 'center', color: '#5E051D', marginBottom: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 10 },
  metalButton: { 
    backgroundColor: '#ddd', 
    padding: 10, 
    borderRadius: 10, 
    flex: 1, // Allow buttons to take equal space
    marginHorizontal: 5, // Add margin for spacing
  },
  selectedMetal: { backgroundColor: '#5E051D' },
  buttonText: { color: 'white', fontSize: 14, textAlign: 'center' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderColor: '#5E051D', paddingBottom: 5, marginBottom: 10 },
  input: { flex: 1, marginLeft: 5, fontSize: 16 },
  amountRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  amountButton: { 
    backgroundColor: '#5E051D', 
    padding: 2, 
    borderRadius: 5, 
    flex: 1, // Allow buttons to take equal space
    marginHorizontal: 6, // Add margin for spacing
  },
  amountText: { color: 'white', fontSize: 10, textAlign: 'center' },
  summaryContainer: { 
    padding: 10, 
    borderTopWidth: 1, 
    borderColor: '#5E051D',
    alignItems: 'flex-start',
  },  
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', width: '100%' },
  separator: { height: 1, backgroundColor: '#5E051D', width: '100%', marginVertical: 5 },
  summaryText: { fontSize: 16, color: '#000' },
  totalText: { fontSize: 18, fontWeight: 'bold', color: '#5E051D', marginTop: 5 },
  buyNowButton: {
    backgroundColor: '#5E051D',
    padding: 12,
    borderRadius: 7,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 7,
    width: '80%',
    alignSelf: 'center',
  },
  buyNowText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  radioButtonContainer: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 10 },
  radioCircle: { 
    height: 20, 
    width: 20, 
    borderRadius: 10, 
    borderWidth: 2, 
    borderColor: '#5E051D', 
    alignItems: 'center', 
    justifyContent: 'center', 
    marginRight: 5 
  },
  selectedRadio: { backgroundColor: '#5E051D', width: 12, height: 12, borderRadius: 6 },
  radioText: { fontSize: 16, color: '#333' },
  
});
export default BuyDigitalGold;
